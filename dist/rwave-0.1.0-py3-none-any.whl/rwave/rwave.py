class RWave():
    def __init__(self):
        ## -----*----- コンストラクタ -----*----- ##
        return
